<template>
  <div class="page1">
    <!-- primera pagina header -->
    <header class="CommonHeader">
      <div class="logo">
        <img src="/icon.png" alt="Icono" class="icon" />
        <img src="/brand.png" alt="Rifat Richani" class="brand" />
      </div>
      
      <nav class="primary-nav">
        <!-- cambiar para que se vea como el search btn -->
        <button @click="toggleMenu" class="menu-btn">
          <span>{{ isMenuOpen ? 'Cerrar' : 'Menu' }}</span>
        </button> 
        <button @click="signIn" class="inc-btn">
          <span>Iniciar Sesión</span>
        </button> 
      </nav>
    </header>

    <!-- Sección principal -->
    <main>
      <section class="background">
        <!-- Fondo 1 -->
        <div class="imagen">
          <img src="/PhotoPrincipal.png" alt="foto de portada" />
        </div>

        <!-- Menú flotante -->
        <aside class="side-menu">
            <button class="icon-btn toggle-btn" @click="toggleSidemenu">
              <img src="/arrow.png" alt="flecha" class="icon-arrow" :class="{ 'rotated': !isOpen }"/>
            </button>
          <div class="extra-btn" :class="{ 'is-closed': !isOpen }">
            <a href="tel:+584145936070" class="icon-btn">
              <img src="/phone.png" alt="telefono" class="icon-phone" />
            </a>
            <a href="mailto:rrbrventas01@gmail.com" class="icon-btn">
              <img src="/gmail.png" alt="gmail" class="icon-gmail" />
            </a>
            <a href="https://wa.me/584145936070" target="_blank" rel="noopener noreferrer" class="icon-btn">
              <img src="/whatsapp.svg" alt="whatsapp" class="icon-whatsapp" />
            </a>
          </div>
        </aside>

        <!-- Barra de filtros -->
        <div class="filter-bar">
          <div class="filter-group">
            <label for="locacion">Locación</label>
            <select id="locacion" name="locacion">
              <option value="" disabled selected>Ciudades</option>
              <option value="valencia">Valencia</option>
              <option value="naguanagua">Naguanagua</option>
              <option value="san_diego">San Diego</option>
              <option value="puerto_cabello">Puerto Cabello</option>
              <option value="guacara">Guacara</option>
              <option value="los_guayos">Los Guayos</option>
              <option value="tocuyito">Tocuyito (Libertador)</option>
              <option value="san_joaquin">San Joaquín</option>
              <option value="diego_ibarra">Mariara (Diego Ibarra)</option>
              <option value="bejuma">Bejuma</option>
              <option value="montalban">Montalbán</option>
              <option value="miranda">Miranda</option>
              <option value="carlos_arvelo">Güigüe (Carlos Arvelo)</option>
              <option value="juan_jose_mora">Morón (Juan José Mora)</option>
            </select>
          </div>

          <div class="filter-group">
            <label for="tipo">Tipo de Propiedad</label>
            <select id="tipo" name="tipo">
              <option value="casa">Casa</option>
              <option value="apartamento">Apartamento</option>
              <option value="townhouse">Townhouse</option>
              <option value="terreno">Terreno</option>
              <option value="local comercial">Local comercial</option>
              <option value="galpon">Galpon</option>
              <option value="oficina">Oficina</option>
              <option value="consultorio medico">Consultorio medico</option>
              <option value="club">Club</option>
              <option value="negocio">Negocio</option>
            </select>
          </div>

          <div class="filter-group">
            <label for="precio">Precio</label>
            <input 
            class="filter-input"
              type="number" 
              id="precio" 
              min="0"
              max="100000000"
              name="precio" 
              placeholder="Ej: 15000"
            />
          </div>

          <div class="filter-group">
            <label for="modalidad">Alquiler o Compra</label>
            <select id="modalidad" name="modalidad">
              <option value="compra">Compra</option>
              <option value="alquiler">Alquiler</option>
            </select>
          </div>
          
          <button @click="Search" class="search-btn">
            <img src="/lupa.svg" alt="" />
            <span>Buscar Propiedad</span>
          </button>
        </div>
      </section>
    </main>

  <div class="menu-container" :class="{ 'open': isMenuOpen }">
    <!-- Navegación superior -->
    <header class="navbar">
      <button @click="toggleMenu" class="nav-link">
        Salir
      </button>
      <img src="/brand2.png" alt="Rifat Richani" class="brand" />
      <button @click="signIn" class="inc-btn">
        <span>Iniciar Sesión</span>
      </button>
    </header>

    <!-- Menú principal centrado -->
    <main class="menu-content">
      <nav class="menu-list">
        <button @click="Home" class="menu-item active"><span>Principal</span></button> 
        <button @click="Search" class="menu-item"><span>Disponibles</span></button> 
        <a href="#" class="menu-item">Favoritos</a>
        <button @click="Contact" class="menu-item"><span>Contactanos</span></button> 

      </nav>
    </main>
  </div>

  </div>

      <!-- DESTACADOS 2DA PAGINA -->
      <section class="featured-section">
        <!-- Encabezado de la sección -->
        <header class="section-header">
          <h2>Destacados</h2>
          <p>Selecciona tu locación</p>
        </header>

        <!-- Contenedor del Grid/Carrusel de tarjetas -->
        <div class="cards-grid">
          <!-- TARJETA 1 -->
            <article class="card" v-for="property in properties" :key="property.id">
            <div class="card-image-wrapper">
              <img :src="property.image" :alt="property.title" class="building-img" />
            </div>

            <div class="card-content">
              <div class="card-location">
                <img src="/location.png" alt="Ubicación" />
                <span>{{ property.location }}</span>
              </div>

              <button class="favorite-btn" :class="{ 'active': isFavorite }" @click="property.isFavorite = !property.isFavorite" aria-label="Añadir a favoritos">
                <img :src="property.isFavorite ? '/filledheart.png' : '/heart.png'" alt="Favorito" />
              </button>

              <h3 class="card-title">{{ property.title }}</h3>

              <div class="card-details">
                <span>{{ property.bedrooms }} habitaciones | {{ property.bathrooms }} baños</span>
                <span>{{ property.area }} m² Totales</span>
              </div>

              <div class="card-footer">
                <span class="card-price">${{ property.price }}</span>
                <button @click="HomeDetails" class="details-btn">
                  <span>Ver Detalles &gt;</span>
                </button> 
              </div>
            </div>
          </article>

        </div>

        <!-- Botón de Navegación del Carrusel -->
        <button class="next-btn" aria-label="Siguiente">
          <img src="/arrow.png" alt="Siguiente" />
        </button>
      </section>

      <!-- PÁGINA 3 -->
      <section class="info-section">
        <header class="CommonHeader">
          <div class="logo">
            <img src="/icon.png" alt="Icono" class="icon" />
            <img src="/brand.png" alt="Rifat Richani" class="brand" />
          </div>
      
          <nav class="primary-nav">
            <button @click="toggleMenu" class="menu-btn">
              <span>{{ isMenuOpen ? 'Cerrar' : 'Menu' }}</span>
            </button> 
            <button class="inc-btn" @click="signIn">
              <span>Iniciar Sesión</span>
            </button>

          </nav>
        </header>

        <div class="section-content">
          <h1 class="principal-text">24 Años Transformando Espacios</h1>
          
          <p class="little-text">
            "Brindar asesoría inmobiliaria de alto nivel en la compra, venta y alquiler de propiedades , resguardando el patrimonio de nuestros clientes con transparencia, criterio estratégico y una estricta seguridad jurídica, garantizando que cada operación sea una decisión rentable y segura."
          </p>
        </div>
      </section>

  <!-- PÁGINA 4-->
  <section class = "page-4">
      <header class="CommonHeader">
          <div class="logo">
            <img src="/icon.png" alt="Icono" class="icon" />
            <img src="/brand.png" alt="Rifat Richani" class="brand" />
          </div>
      
          <nav class="primary-nav">
            <button @click="toggleMenu" class="menu-btn">
              <span>{{ isMenuOpen ? 'Cerrar' : 'Menu' }}</span>
            </button>
            <button class="inc-btn" @click="signIn">Iniciar Sesión</button>
          </nav>
      </header>
        <div class="vision-container">
          <article class="image-article">
            <div class="image-4">
              <img src="/building.png" alt="Residencias Altos Del Mirador" class="building-img" />
            </div>
          </article>
          <article class="text-article">
            <h1 class="text-4">Nuestra vision</h1>
            <p class="text-little-4">
            "Consolidarnos como la firma inmobiliaria referente y de mayor confianza en, reconocida por nuestra trayectoria, innovación y excelencia en la gestión personalizada de activos residenciales y comerciales en las zonas de mayor valorización en el estado."
            </p>
          </article>
        </div>
  </section>
  <!-- PÁGINA 5-->

  <section class="container">
    <!-- Banner Superior de datos -->
    <div class="banner">
      <div class="stat-item">
        <div class="stat-number">600+</div>
        <div class="stat-label">VIVIENDAS</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">24+</div>
        <div class="stat-label">AÑOS APOYANDO A CARABOBO</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">350+</div>
        <div class="stat-label">CLIENTES</div>
      </div>
    </div>

    <!-- Sección why us? -->
    <div class="content">
      <!-- Imagen de la persona -->
      <div class="profile-image">
        <img src="/profile.png" alt="Perfil" class="profile-img" />
      </div>

      <!-- Texto descriptivo -->
      <div class="info-text">
        <h2 class="section-title">¿Por qué nosotros?</h2>
        <p class="description">
          Rifat Richani is an artful mosaic of luxury residences that blend
          minimalist details with modern living. A serene community where
          thoughtful design and exceptional amenities invites you to embrace an
          elevated lifestyle in Long Island City.
        </p>

        <!-- Botón flotante opcional (si aplica en la sección) -->
      <button class="next-btn" aria-label="Siguiente">
          <img src="/arrow.png" alt="Siguiente" />
      </button>
      </div>
    </div>
  </section>
  

  <!-- PÁGINA 6-->
  <footer class="page-6">
    <!-- boton superior derecho-->
    <div class="login-6">  
      <button class="inc-btn" @click="signIn">Iniciar Sesion</button>
    </div>
    <!--contenido central-->
    <div class="footer-content">
      <div class="logo">
        <img src="/icon.png" alt="Rifat Richani Bienes Raices" class="footer-brand-img" />
      </div>
      <!-- Direccion-->
      <p class="footer-address">
        C.C.P. Otama, urb. El Viñedo, PB<br />
        Local 10, Valencia, Carabobo
      </p>
      <!--Titulo de contacto-->
      <h3 class="contact-title">CONTACTANOS</h3>

      <!--Iconos de redes sociales-->
      <div class="social-icons">
        <a href="https://x.com/rifatrichanibr"><img src="/x.png" alt="X (Twitter)" /></a>
        <a href="https://www.instagram.com/rifatrichanibienesraices?stkn=c2YydWl4c3Q4anNr"><img src="/inst.png" alt="Instagram" /></a>
        <a href="https://www.facebook.com/share/19A5MuKs4X/?mibextid=wwXIfr"><img src="/facebook.png" alt="Facebook" /></a>
        <a href="https://wa.me/584145936070"><img src="/whatsapp.png" alt="WhatsApp"></a>
      </div>



    </div>


  </footer>

</template>

<script setup>
import {ref} from 'vue'
import {useRouter} from 'vue-router'

const isFavorite = ref(false)
const toggleFavorite = () => {
  isFavorite.value = !isFavorite.value
}
const properties = ref([
  {
    id: 1,
    title: 'Residencias Altos Del Mirador',
    location: 'Valencia, Via Guataparo',
    bedrooms: 4,
    bathrooms: 3,
    area: 67,
    price: 150000,
    image: '/building.png',
    isFavorite: false,
  },
  {
    id: 2,
    title: 'Residencias Altos Del Mirador',
    location: 'Valencia, Via Guataparo',
    bedrooms: 4,
    bathrooms: 3,
    area: 67,
    price: 150000,
    image: '/building.png',
    isFavorite: false,
  },
  {
    id: 3,
    title: 'Residencias Altos Del Mirador',
    location: 'Valencia, Via Guataparo',
    bedrooms: 4,
    bathrooms: 3,
    area: 67,
    price: 150000,
    image: '/building.png',
    isFavorite: false,
  },
  {
    id: 4,
    title: 'Residencias Altos Del Mirador',
    location: 'Valencia, Via Guataparo',
    bedrooms: 4,
    bathrooms: 3,
    area: 67,
    price: 150000,
    image: '/building.png',
    isFavorite: false,
  },
])

const router = useRouter()

const Search = ()=> {
  router.push('/search')
}

const isMenuOpen = ref(false)
const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value
}

const HomeDetails = ()=> {
  router.push('/details')
}

const Home = ()=> {
  router.push('/')
}

const Contact = ()=> {
  router.push('/contacts')
}

const signIn = ()=> {
  router.push('/signin')
}

const isOpen = ref(true) // Estado para controlar la visibilidad del menú
const toggleSidemenu = () => {
  isOpen.value = !isOpen.value // Cambia el estado al hacer clic
}
// Lógica de JavaScript / Vue (si es necesaria)




</script>

<style scoped src= "./style.css"></style>
